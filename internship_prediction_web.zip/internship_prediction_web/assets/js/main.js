document.addEventListener('DOMContentLoaded', () => {
  // Fade-up on scroll
  const fadeEls = document.querySelectorAll('.fade-up');
  if ('IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.style.animationPlayState = 'running'; obs.unobserve(e.target); } });
    }, { threshold: 0.1 });
    fadeEls.forEach(el => { el.style.animationPlayState = 'paused'; obs.observe(el); });
  }
  // Active nav
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link-custom').forEach(link => {
    if (link.getAttribute('href') && path.includes(link.getAttribute('href').replace('../',''))) link.classList.add('active');
  });
});
