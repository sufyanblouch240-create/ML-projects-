"""
predict.py — Internship Selection Prediction
Usage: python predict.py "3.5,4,3"
       (cgpa, skills_count, projects_count)
Returns JSON: {"probability": float, "selection_chance": str}
"""

import sys, json, os, pickle
import numpy as np

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'internship_model.pkl')

def predict(cgpa, skills_count, projects):
    if not os.path.exists(MODEL_PATH):
        return {"error": "Model not found. Run train_model.py first."}

    with open(MODEL_PATH, 'rb') as f:
        bundle = pickle.load(f)

    model  = bundle['model']
    scaler = bundle['scaler']

    features = np.array([[cgpa, skills_count, projects]], dtype=float)
    features = scaler.transform(features)

    probability     = float(model.predict_proba(features)[0][1]) * 100
    selection_chance = 'High' if probability >= 65 else ('Medium' if probability >= 40 else 'Low')

    return {"probability": round(probability, 2), "selection_chance": selection_chance}

if __name__ == '__main__':
    try:
        if len(sys.argv) < 2:
            raise ValueError("No input.")
        parts = sys.argv[1].split(',')
        if len(parts) != 3:
            raise ValueError("Expected 3 values: cgpa,skills_count,projects")
        cgpa, skills, projects = float(parts[0]), int(parts[1]), int(parts[2])
        print(json.dumps(predict(cgpa, skills, projects)))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
