"""
train_model.py — Internship Selection Prediction
-------------------------------------------------
Trains a Random Forest classifier on internship dataset.
Run once: python train_model.py
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import pickle, os

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
CSV_PATH   = os.path.join(BASE_DIR, 'dataset', 'internship.csv')
MODEL_PATH = os.path.join(BASE_DIR, 'internship_model.pkl')

# ── Generate synthetic dataset if CSV not found ───────────────────────────────
if not os.path.exists(CSV_PATH):
    print("[*] Dataset not found — generating synthetic dataset (1000 rows)...")
    np.random.seed(42)
    n = 1000

    cgpa          = np.round(np.random.uniform(1.5, 4.0, n), 2)
    skills_count  = np.random.randint(0, 10, n)
    projects      = np.random.randint(0, 15, n)

    # Selection logic: weighted scoring
    score = (cgpa / 4.0) * 0.4 + (skills_count / 10) * 0.35 + (projects / 15) * 0.25
    noise = np.random.normal(0, 0.08, n)
    prob  = np.clip(score + noise, 0, 1)
    selected = (prob >= 0.5).astype(int)

    df = pd.DataFrame({'cgpa': cgpa, 'skills_count': skills_count, 'projects': projects, 'selected': selected})
    os.makedirs(os.path.dirname(CSV_PATH), exist_ok=True)
    df.to_csv(CSV_PATH, index=False)
    print(f"[✓] Synthetic dataset saved: {CSV_PATH}")
else:
    df = pd.read_csv(CSV_PATH)
    print(f"[*] Loaded dataset: {CSV_PATH} — {df.shape[0]} rows")

# ── Features & target ─────────────────────────────────────────────────────────
feature_cols = ['cgpa', 'skills_count', 'projects']
target_col   = 'selected'

# Normalize column names
df.columns = df.columns.str.strip().str.lower()
for c in feature_cols + [target_col]:
    if c not in df.columns:
        raise ValueError(f"Column '{c}' not found. Available: {list(df.columns)}")

X = df[feature_cols]
y = df[target_col]

print(f"[*] Class distribution:\n{y.value_counts()}")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

print("[*] Training Random Forest...")
model = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
acc    = accuracy_score(y_test, y_pred)
print(f"\n[✓] Accuracy: {acc * 100:.2f}%")
print(classification_report(y_test, y_pred))

with open(MODEL_PATH, 'wb') as f:
    pickle.dump({'model': model, 'scaler': scaler}, f)

print(f"[✓] Model saved: {MODEL_PATH}")
