<?php
$pageTitle = 'Home';
$pathDepth = 0;
require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<main>
  <!-- HERO -->
  <section class="hero-section">
    <div class="container">
      <p class="hero-eyebrow fade-up">AI-Powered Career Intelligence</p>
      <h1 class="hero-title fade-up fade-up-d1">
        Know Your Internship<br><em>Selection Chances</em>
      </h1>
      <p class="hero-desc fade-up fade-up-d2">
        Enter your CGPA, technical skills, and project count — our trained ML model predicts
        how likely you are to get selected for an internship.
      </p>
      <div class="hero-btns fade-up fade-up-d3">
        <?php if (isset($_SESSION['user_id'])): ?>
          <a href="pages/predict.php" class="btn-prime" style="font-size:1rem;padding:0.8rem 2rem">
            <i class="bi bi-cpu me-2"></i>Check My Chances
          </a>
          <a href="pages/dashboard.php" class="btn-outline-prime" style="padding:0.75rem 1.8rem">Go to Dashboard</a>
        <?php else: ?>
          <a href="auth/register.php" class="btn-prime" style="font-size:1rem;padding:0.8rem 2rem">
            <i class="bi bi-person-plus me-2"></i>Get Started Free
          </a>
          <a href="auth/login.php" class="btn-outline-prime" style="padding:0.75rem 1.8rem">
            <i class="bi bi-box-arrow-in-right me-2"></i>Login
          </a>
        <?php endif; ?>
      </div>
      <div class="stat-row fade-up">
        <div class="stat-pill"><strong>~88%</strong> Model Accuracy</div>
        <div class="stat-pill"><strong>3</strong> Key Parameters</div>
        <div class="stat-pill"><strong>&lt;2s</strong> Instant Result</div>
        <div class="stat-pill"><strong>Free</strong> No Cost</div>
      </div>
    </div>
  </section>

  <hr class="divider">

  <!-- WHY IT MATTERS -->
  <section class="py-5">
    <div class="container">
      <p class="section-label text-center">Why Use InternIQ?</p>
      <h2 class="section-title text-center mb-2">The Internship Problem</h2>
      <p class="text-center mb-4" style="color:var(--text-muted);max-width:560px;margin:0 auto 2.5rem">
        Thousands of students apply for internships every year — but most don't know where they stand.
      </p>
      <div class="features-grid">
        <div class="feature-card fade-up">
          <div class="feature-icon">🎯</div>
          <h4>Know Before You Apply</h4>
          <p>Understand your selection probability before spending time on applications that may not match your profile.</p>
        </div>
        <div class="feature-card fade-up fade-up-d1">
          <div class="feature-icon">📊</div>
          <h4>Data-Driven Insights</h4>
          <p>Our model is trained on real internship selection patterns — CGPA, skills, and project experience matter most.</p>
        </div>
        <div class="feature-card fade-up fade-up-d2">
          <div class="feature-icon">🤖</div>
          <h4>ML-Powered Analysis</h4>
          <p>Random Forest algorithm trained on student profiles gives you an accurate, unbiased prediction in seconds.</p>
        </div>
        <div class="feature-card fade-up fade-up-d3">
          <div class="feature-icon">💡</div>
          <h4>Actionable Tips</h4>
          <p>Get personalized recommendations on what to improve — whether it's your CGPA, skills, or project portfolio.</p>
        </div>
      </div>
    </div>
  </section>

  <hr class="divider">

  <!-- HOW IT WORKS -->
  <section class="py-5">
    <div class="container">
      <p class="section-label text-center">Simple Process</p>
      <h2 class="section-title text-center mb-4">How It Works</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--blue-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">1</div>
            <h5 class="fw-700 mb-2">Create Account</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Register free and login securely to access the AI prediction tool.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--blue-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">2</div>
            <h5 class="fw-700 mb-2">Enter Your Profile</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Provide your CGPA, technical skills, and number of completed projects.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--blue-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">3</div>
            <h5 class="fw-700 mb-2">Get Your Result</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Receive your selection probability, chance level, and personalized recommendations.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<?php require_once 'includes/footer.php'; ?>
