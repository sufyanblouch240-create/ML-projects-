<?php
$pageTitle = 'Forgot Password'; $pathDepth = 1;
session_start();
require_once '../includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card">
    <p class="auth-logo"><i class="bi bi-briefcase-fill me-2"></i>InternIQ</p>
    <p class="auth-subtitle">Reset your password</p>
    <div class="alert-custom alert-info"><i class="bi bi-info-circle me-2"></i>Contact your administrator to reset your password.</div>
    <a href="login.php" class="btn-outline-prime d-block text-center"><i class="bi bi-arrow-left me-2"></i>Back to Login</a>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
