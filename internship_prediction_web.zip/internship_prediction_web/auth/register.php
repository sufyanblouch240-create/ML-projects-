<?php
$pageTitle = 'Register';
$pathDepth = 1;
session_start();
if (isset($_SESSION['user_id'])) { header('Location: ../pages/dashboard.php'); exit; }
require_once '../config/db.php';
$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['full_name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($name)||empty($email)||empty($pass)||empty($confirm)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($pass !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $chk = $conn->prepare("SELECT id FROM users WHERE email=?");
        $chk->bind_param('s',$email); $chk->execute(); $chk->store_result();
        if ($chk->num_rows > 0) {
            $error = 'Email already registered.';
        } else {
            $hashed = password_hash($pass, PASSWORD_BCRYPT);
            $ins = $conn->prepare("INSERT INTO users (full_name,email,password) VALUES (?,?,?)");
            $ins->bind_param('sss',$name,$email,$hashed);
            $success = $ins->execute() ? 'Account created! <a href="login.php" style="color:var(--success);font-weight:700">Login →</a>' : 'Registration failed.';
            $ins->close();
        }
        $chk->close();
    }
}
require_once '../includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card">
    <p class="auth-logo"><i class="bi bi-briefcase-fill me-2"></i>InternIQ</p>
    <p class="auth-subtitle">Create your free account</p>
    <?php if ($error):   ?><div class="alert-custom alert-error"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert-custom alert-success"><i class="bi bi-check-circle me-2"></i><?= $success ?></div><?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label-custom">Full Name</label>
        <input type="text" name="full_name" class="form-control-custom" placeholder="Your Name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label-custom">Email Address</label>
        <input type="email" name="email" class="form-control-custom" placeholder="you@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label-custom">Password <span style="font-size:0.75rem;color:var(--text-muted)">(min 6 chars)</span></label>
        <input type="password" name="password" class="form-control-custom" placeholder="••••••••" required>
      </div>
      <div class="mb-4">
        <label class="form-label-custom">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-control-custom" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn-prime w-100" style="padding:0.75rem;font-size:0.95rem">
        <i class="bi bi-person-plus me-2"></i>Create Account
      </button>
    </form>
    <p class="text-center mt-3" style="font-size:0.85rem;color:var(--text-muted)">
      Already registered? <a href="login.php" style="color:var(--blue-lite);text-decoration:none;font-weight:600">Sign in</a>
    </p>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
