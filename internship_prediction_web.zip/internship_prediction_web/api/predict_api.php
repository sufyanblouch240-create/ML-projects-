<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ../pages/predict.php'); exit; }

require_once '../config/db.php';

$userId        = (int)$_SESSION['user_id'];
$cgpa          = (float)($_POST['cgpa'] ?? 0);
$skillsArr     = $_POST['skills'] ?? [];
$projectsCount = (int)($_POST['projects_count'] ?? 0);
$skillsList    = implode(', ', array_map('htmlspecialchars', $skillsArr));
$skillsScore   = count($skillsArr);

// ── Call Python ML ────────────────────────────────────────────────────────────
$pythonPath = 'python';   // use 'python3' on Linux/Mac
$scriptPath = __DIR__ . '/../ml_model/predict.py';
$input = escapeshellarg("$cgpa,$skillsScore,$projectsCount");
$output = shell_exec("$pythonPath $scriptPath $input 2>&1");
$mlResult = json_decode(trim($output), true);

// ── Fallback heuristic if ML fails ───────────────────────────────────────────
if (!$mlResult || !isset($mlResult['probability'])) {
    $score = 0;
    // CGPA weight: 40%
    $score += ($cgpa / 4.0) * 40;
    // Skills weight: 35%
    $score += min(($skillsScore / 5) * 35, 35);
    // Projects weight: 25%
    $score += min(($projectsCount / 5) * 25, 25);
    $score = min(98, max(5, round($score + rand(-3,3))));

    $probability     = (float)$score;
    $selectionChance = $probability >= 65 ? 'High' : ($probability >= 40 ? 'Medium' : 'Low');
} else {
    $probability     = (float)$mlResult['probability'];
    $selectionChance = $mlResult['selection_chance'] ?? ($probability >= 65 ? 'High' : ($probability >= 40 ? 'Medium' : 'Low'));
}

// ── Build recommendations ─────────────────────────────────────────────────────
$recommendations = [];

if ($selectionChance === 'High') {
    $recommendations[] = 'Your profile is competitive — start applying to top internships now!';
    $recommendations[] = 'Prepare a strong resume highlighting your projects and skills.';
    $recommendations[] = 'Practice DSA and system design for technical interviews.';
    $recommendations[] = 'Build a GitHub portfolio to showcase your work to recruiters.';
} elseif ($selectionChance === 'Medium') {
    $recommendations[] = 'You have potential — focus on adding 1-2 more technical skills.';
    $recommendations[] = 'Complete at least one industry-relevant project before applying.';
    $recommendations[] = 'Consider getting certifications (Coursera, Google, AWS) to boost your profile.';
    $recommendations[] = 'Practice LeetCode easy/medium problems for coding interviews.';
} else {
    $recommendations[] = 'Focus on improving your CGPA — aim for at least 2.8+.';
    $recommendations[] = 'Start learning in-demand skills: Python, SQL, or JavaScript.';
    $recommendations[] = 'Work on at least 1-2 small projects to build your portfolio.';
    $recommendations[] = 'Join university tech clubs and participate in hackathons.';
    $recommendations[] = 'Apply for beginner-friendly internships and open source contributions.';
}

if ($cgpa < 2.5)        $recommendations[] = 'Low CGPA is a significant barrier — focus on academics this semester.';
if ($skillsScore === 0) $recommendations[] = 'No skills selected — start with Python or JavaScript as your first skill.';
if ($skillsScore >= 5)  $recommendations[] = 'Great skills portfolio! Make sure you have projects demonstrating each skill.';
if ($projectsCount >= 5) $recommendations[] = 'Excellent project count! Host them on GitHub with proper READMEs.';
if ($projectsCount < 2)  $recommendations[] = 'Build at least 2 projects — even small ones show initiative to recruiters.';

// ── Save to DB ────────────────────────────────────────────────────────────────
$recText = implode(' | ', $recommendations);
$stmt = $conn->prepare("
    INSERT INTO predictions
        (user_id, cgpa, skills_score, skills_list, projects_count, selection_chance, probability, recommendation)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param('idisidss', $userId, $cgpa, $skillsScore, $skillsList, $projectsCount, $selectionChance, $probability, $recText);
$stmt->execute();
$stmt->close();

// ── Store result in session ───────────────────────────────────────────────────
$_SESSION['last_result'] = [
    'selection_chance' => $selectionChance,
    'probability'      => round($probability, 2),
    'cgpa'             => $cgpa,
    'skills_list'      => $skillsList,
    'projects_count'   => $projectsCount,
    'recommendations'  => $recommendations,
];

header('Location: ../pages/result.php');
exit;
?>
