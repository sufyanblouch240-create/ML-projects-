<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$base = isset($pathDepth) ? str_repeat('../', $pathDepth) : '';
$isLoggedIn = isset($_SESSION['user_id']);
?>
<nav class="navbar-main navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand-custom" href="<?= $base ?>index.php">
      <i class="bi bi-briefcase-fill me-2"></i>Intern<span>IQ</span>
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" style="color:var(--text-muted)">
      <i class="bi bi-list fs-4"></i>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-1">
        <li class="nav-item">
          <a class="nav-link-custom" href="<?= $base ?>index.php"><i class="bi bi-house me-1"></i>Home</a>
        </li>
        <?php if ($isLoggedIn): ?>
          <li class="nav-item"><a class="nav-link-custom" href="<?= $base ?>pages/dashboard.php"><i class="bi bi-grid me-1"></i>Dashboard</a></li>
          <li class="nav-item"><a class="nav-link-custom" href="<?= $base ?>pages/predict.php"><i class="bi bi-cpu me-1"></i>Predict</a></li>
          <li class="nav-item"><a class="nav-link-custom" href="<?= $base ?>pages/history.php"><i class="bi bi-clock-history me-1"></i>History</a></li>
          <li class="nav-item ms-2">
            <div class="dropdown">
              <button class="btn-outline-prime dropdown-toggle border-0" style="background:var(--blue-glow);border:1px solid var(--card-border)!important;color:var(--text-primary)" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($_SESSION['user_name'] ?? 'User') ?>
              </button>
              <ul class="dropdown-menu dropdown-menu-end" style="background:var(--card-bg);border:1px solid var(--card-border)">
                <li><a class="dropdown-item" style="color:var(--text-muted);font-size:0.88rem" href="<?= $base ?>auth/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
              </ul>
            </div>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link-custom" href="<?= $base ?>auth/login.php">Login</a></li>
          <li class="nav-item"><a class="btn-prime ms-2" href="<?= $base ?>auth/register.php">Get Started</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
