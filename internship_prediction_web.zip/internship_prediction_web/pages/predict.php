<?php
$pageTitle = 'Internship Prediction'; $pathDepth = 1;
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$allSkills = ['Python','Machine Learning','Data Analysis','JavaScript','React','PHP','Java','C++','SQL','Git','Deep Learning','NLP','Django','Flutter','Kotlin'];
?>
<div class="page-wrapper">
  <div class="container">
    <div class="predict-header fade-up">
      <h2>Internship Selection Predictor</h2>
      <p>Fill in your academic profile — the AI model will calculate your selection probability.</p>
    </div>

    <form method="POST" action="../api/predict_api.php" id="predictForm">
      <div class="row g-4">

        <!-- LEFT -->
        <div class="col-lg-7">

          <!-- CGPA -->
          <div class="card-custom mb-3 fade-up">
            <span class="step-badge">Parameter 1 of 3</span>
            <label class="form-label-custom">CGPA / GPA <span style="font-size:0.78rem;color:var(--text-muted)">(out of 4.0)</span></label>
            <input type="range" name="cgpa" id="cgpaRange" min="1.0" max="4.0" step="0.1" value="3.0"
                   oninput="document.getElementById('cgpaVal').textContent=parseFloat(this.value).toFixed(1); updateSummary();">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">1.0</span>
              <span class="range-val" id="cgpaVal">3.0</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">4.0</span>
            </div>
            <div class="d-flex gap-2 mt-2 flex-wrap">
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(239,68,68,0.15);color:var(--danger)">Below 2.5 — Weak</span>
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(245,158,11,0.15);color:var(--warning)">2.5–3.0 — Average</span>
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(16,185,129,0.15);color:var(--success)">3.0+ — Strong</span>
            </div>
          </div>

          <!-- SKILLS -->
          <div class="card-custom mb-3 fade-up fade-up-d1">
            <span class="step-badge">Parameter 2 of 3</span>
            <label class="form-label-custom">Technical Skills <span style="color:var(--blue-lite)" id="skillCountLabel">(0 selected)</span></label>
            <div class="skill-grid" id="skillGrid">
              <?php foreach ($allSkills as $skill): ?>
              <label class="skill-chip" id="chip-<?= str_replace(' ','_',$skill) ?>">
                <input type="checkbox" name="skills[]" value="<?= htmlspecialchars($skill) ?>"
                       onchange="updateSkillCount(); updateSummary();">
                <?= htmlspecialchars($skill) ?>
              </label>
              <?php endforeach; ?>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:0.7rem"><i class="bi bi-info-circle me-1"></i>Select all skills you have practical experience with</p>
          </div>

          <!-- PROJECTS -->
          <div class="card-custom mb-3 fade-up fade-up-d2">
            <span class="step-badge">Parameter 3 of 3</span>
            <label class="form-label-custom">Completed Projects <span style="font-size:0.78rem;color:var(--text-muted)">(personal, academic, or open source)</span></label>
            <input type="range" name="projects_count" id="projRange" min="0" max="20" value="2"
                   oninput="document.getElementById('projVal').textContent=this.value; updateSummary();">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">0</span>
              <span class="range-val" id="projVal">2</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">20 projects</span>
            </div>
            <div class="d-flex gap-2 mt-2 flex-wrap">
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(239,68,68,0.15);color:var(--danger)">0–1 — Limited</span>
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(245,158,11,0.15);color:var(--warning)">2–4 — Good</span>
              <span style="font-size:0.75rem;padding:0.2rem 0.6rem;border-radius:20px;background:rgba(16,185,129,0.15);color:var(--success)">5+ — Excellent</span>
            </div>
          </div>

        </div>

        <!-- RIGHT: Summary -->
        <div class="col-lg-5">
          <div class="card-custom fade-up" style="position:sticky;top:90px">
            <h6 class="fw-700 mb-3" style="font-size:0.9rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted)">
              <i class="bi bi-person-badge me-2 text-blue"></i>Profile Summary
            </h6>
            <div style="display:flex;flex-direction:column;gap:0.6rem;margin-bottom:1.5rem">
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">CGPA</span>
                <span class="fw-700" id="s-cgpa">3.0 / 4.0</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">Skills Selected</span>
                <span class="fw-700" id="s-skills">0</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem">
                <span style="color:var(--text-muted)">Projects</span>
                <span class="fw-700" id="s-projects">2</span>
              </div>
            </div>

            <!-- Live strength meter -->
            <div style="margin-bottom:1.5rem">
              <div class="d-flex justify-content-between mb-1" style="font-size:0.8rem">
                <span style="color:var(--text-muted)">Profile Strength</span>
                <span id="strengthLabel" style="font-weight:700;color:var(--blue-lite)">—</span>
              </div>
              <div style="background:rgba(255,255,255,0.08);border-radius:20px;height:8px;overflow:hidden">
                <div id="strengthBar" style="height:100%;border-radius:20px;background:var(--blue-mid);width:0%;transition:width 0.4s,background 0.4s"></div>
              </div>
            </div>

            <button type="submit" class="btn-prime w-100 mb-2" id="submitBtn" style="padding:0.85rem;font-size:1rem">
              <i class="bi bi-cpu me-2"></i>Run AI Prediction
            </button>
            <p style="font-size:0.75rem;color:var(--text-muted);text-align:center;line-height:1.5">
              Results are generated by a Random Forest ML model.<br>For guidance only.
            </p>
          </div>
        </div>

      </div>
    </form>
  </div>
</div>

<script>
function updateSkillCount() {
  const checked = document.querySelectorAll('input[name="skills[]"]:checked').length;
  document.getElementById('skillCountLabel').textContent = '(' + checked + ' selected)';
  document.querySelectorAll('.skill-chip').forEach(chip => {
    chip.classList.toggle('selected', chip.querySelector('input').checked);
  });
}

function updateSummary() {
  const cgpa     = parseFloat(document.getElementById('cgpaRange').value).toFixed(1);
  const skills   = document.querySelectorAll('input[name="skills[]"]:checked').length;
  const projects = document.getElementById('projRange').value;

  document.getElementById('s-cgpa').textContent    = cgpa + ' / 4.0';
  document.getElementById('s-skills').textContent  = skills + ' skill' + (skills !== 1 ? 's' : '');
  document.getElementById('s-projects').textContent = projects + ' project' + (projects != 1 ? 's' : '');

  // Strength meter
  let score = 0;
  score += Math.min((parseFloat(cgpa) / 4.0) * 40, 40);
  score += Math.min((skills / 5) * 35, 35);
  score += Math.min((parseInt(projects) / 5) * 25, 25);
  score = Math.round(score);

  document.getElementById('strengthBar').style.width = score + '%';
  const bar = document.getElementById('strengthBar');
  const lbl = document.getElementById('strengthLabel');
  if (score >= 70) { bar.style.background = 'var(--success)'; lbl.textContent = 'Strong (' + score + '%)'; lbl.style.color = 'var(--success)'; }
  else if (score >= 45) { bar.style.background = 'var(--warning)'; lbl.textContent = 'Average (' + score + '%)'; lbl.style.color = 'var(--warning)'; }
  else { bar.style.background = 'var(--danger)'; lbl.textContent = 'Weak (' + score + '%)'; lbl.style.color = 'var(--danger)'; }
}

document.getElementById('predictForm').addEventListener('submit', function() {
  const btn = document.getElementById('submitBtn');
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Analyzing...';
  btn.disabled = true;
});

updateSummary();
</script>
<?php require_once '../includes/footer.php'; ?>
