<?php
$pageTitle = 'Prediction History'; $pathDepth = 1;
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$userId = (int)$_SESSION['user_id'];
$stmt   = $conn->prepare("SELECT id, cgpa, skills_list, projects_count, selection_chance, probability, created_at FROM predictions WHERE user_id=? ORDER BY created_at DESC");
$stmt->bind_param('i', $userId); $stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 fade-up">
      <div>
        <h2 style="font-family:'DM Serif Display',serif;font-size:2rem">Prediction History</h2>
        <p style="color:var(--text-muted);font-size:0.9rem;margin-top:0.2rem">All your previous internship predictions</p>
      </div>
      <a href="predict.php" class="btn-prime text-decoration-none"><i class="bi bi-plus-lg me-2"></i>New Prediction</a>
    </div>

    <?php if (empty($rows)): ?>
      <div class="card-custom text-center py-5 fade-up">
        <div style="font-size:3rem;margin-bottom:1rem">💼</div>
        <h5 class="fw-700 mb-2">No Predictions Yet</h5>
        <p style="color:var(--text-muted);font-size:0.9rem;margin-bottom:1.5rem">Run your first prediction to see results here.</p>
        <a href="predict.php" class="btn-prime text-decoration-none"><i class="bi bi-cpu me-2"></i>Start Predicting</a>
      </div>

    <?php else:
      $total  = count($rows);
      $high   = count(array_filter($rows, fn($r) => $r['selection_chance'] === 'High'));
      $med    = count(array_filter($rows, fn($r) => $r['selection_chance'] === 'Medium'));
      $avgP   = round(array_sum(array_column($rows, 'probability')) / $total, 1);
      $avgCgpa= round(array_sum(array_column($rows, 'cgpa')) / $total, 2);
    ?>
      <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up"><div class="dash-stat-icon">📊</div><div><p class="dash-stat-label">Total</p><p class="dash-stat-value"><?= $total ?></p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d1"><div class="dash-stat-icon">✅</div><div><p class="dash-stat-label">High Chance</p><p class="dash-stat-value" style="color:var(--success)"><?= $high ?></p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d2"><div class="dash-stat-icon">📈</div><div><p class="dash-stat-label">Avg Probability</p><p class="dash-stat-value"><?= $avgP ?>%</p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d3"><div class="dash-stat-icon">🎓</div><div><p class="dash-stat-label">Avg CGPA</p><p class="dash-stat-value"><?= $avgCgpa ?></p></div></div></div>
      </div>

      <div class="card-custom fade-up" style="overflow-x:auto">
        <table class="hist-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Date</th>
              <th>CGPA</th>
              <th>Skills</th>
              <th>Projects</th>
              <th>Chance</th>
              <th>Probability</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $row):
              $bc = $row['selection_chance'] === 'High' ? 'chance-high' : ($row['selection_chance'] === 'Medium' ? 'chance-medium' : 'chance-low');
              $skillsShort = strlen($row['skills_list']) > 30 ? substr($row['skills_list'],0,28).'…' : $row['skills_list'];
            ?>
            <tr>
              <td style="color:var(--text-muted)"><?= $i+1 ?></td>
              <td><?= date('M d, Y',strtotime($row['created_at'])) ?><br><small style="color:var(--text-muted)"><?= date('H:i',strtotime($row['created_at'])) ?></small></td>
              <td class="fw-700"><?= $row['cgpa'] ?></td>
              <td style="font-size:0.82rem;color:var(--text-muted)"><?= htmlspecialchars($skillsShort ?: '—') ?></td>
              <td><?= $row['projects_count'] ?></td>
              <td><span class="chance-badge <?= $bc ?>"><?= htmlspecialchars($row['selection_chance']) ?></span></td>
              <td class="fw-700"><?= $row['probability'] ?>%</td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
