<?php
$pageTitle = 'Prediction Result'; $pathDepth = 1;
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
if (!isset($_SESSION['last_result'])) { header('Location: predict.php'); exit; }

$r           = $_SESSION['last_result'];
$chance      = $r['selection_chance'];
$probability = $r['probability'];
$cgpa        = $r['cgpa'];
$skills      = $r['skills_list'];
$projects    = $r['projects_count'];
$recs        = $r['recommendations'];
$ringClass   = $chance === 'High' ? 'high' : ($chance === 'Medium' ? 'mid' : 'low');
$chanceColor = $chance === 'High' ? 'var(--success)' : ($chance === 'Medium' ? 'var(--warning)' : 'var(--danger)');

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
  <div class="container" style="max-width:860px">

    <div class="text-center mb-4 fade-up">
      <p class="section-label">AI Analysis Complete</p>
      <h2 style="font-family:'DM Serif Display',serif;font-size:2rem">Your Internship Selection Result</h2>
    </div>

    <div class="row g-4">
      <!-- Ring -->
      <div class="col-md-5">
        <div class="card-custom text-center fade-up h-100">
          <p style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-muted);margin-bottom:0.5rem">Selection Probability</p>
          <div class="result-ring-wrap">
            <div class="result-ring <?= $ringClass ?>">
              <?= round($probability) ?>%
              <small>probability</small>
            </div>
          </div>
          <h3 class="fw-700 mb-1" style="font-size:1.6rem;color:<?= $chanceColor ?>">
            <?= $chance ?> Chance
          </h3>
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:1.5rem">
            <?php
              if ($chance === 'High')   echo 'Excellent profile! You have strong chances of getting selected.';
              elseif ($chance === 'Medium') echo 'Good potential. A few improvements can significantly boost your chances.';
              else echo 'Keep building your profile. Focus on skills and projects to improve.';
            ?>
          </p>

          <div style="background:rgba(255,255,255,0.03);border-radius:10px;padding:1rem;text-align:left">
            <p style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);margin-bottom:0.8rem">Your Profile</p>
            <div class="d-flex justify-content-between" style="font-size:0.83rem;margin-bottom:0.4rem">
              <span style="color:var(--text-muted)">CGPA</span>
              <span class="fw-700"><?= $cgpa ?> / 4.0</span>
            </div>
            <div class="d-flex justify-content-between" style="font-size:0.83rem;margin-bottom:0.4rem">
              <span style="color:var(--text-muted)">Skills</span>
              <span class="fw-700"><?= htmlspecialchars($skills ?: 'None') ?></span>
            </div>
            <div class="d-flex justify-content-between" style="font-size:0.83rem">
              <span style="color:var(--text-muted)">Projects</span>
              <span class="fw-700"><?= $projects ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Recommendations -->
      <div class="col-md-7">
        <div class="card-custom fade-up fade-up-d1 h-100">
          <h5 class="fw-700 mb-3"><i class="bi bi-lightbulb text-blue me-2"></i>Recommendations</h5>
          <?php foreach ($recs as $rec): ?>
            <div class="rec-item"><i class="bi bi-check2-circle text-blue me-2"></i><?= htmlspecialchars($rec) ?></div>
          <?php endforeach; ?>
          <hr class="divider" style="margin:1.2rem 0">
          <div class="d-flex gap-2 flex-wrap">
            <a href="predict.php" class="btn-prime text-decoration-none"><i class="bi bi-arrow-repeat me-2"></i>Try Again</a>
            <a href="history.php" class="btn-outline-prime"><i class="bi bi-clock-history me-2"></i>History</a>
            <a href="dashboard.php" class="btn-outline-prime"><i class="bi bi-grid me-2"></i>Dashboard</a>
          </div>
        </div>
      </div>
    </div>

    <div class="alert-custom alert-info mt-4 fade-up">
      <i class="bi bi-info-circle me-2"></i>
      <strong>Note:</strong> This prediction is based on ML patterns from internship selection data. Results are for guidance only — actual selection depends on many factors including interview performance, company requirements, and timing.
    </div>

  </div>
</div>
<?php unset($_SESSION['last_result']); require_once '../includes/footer.php'; ?>
