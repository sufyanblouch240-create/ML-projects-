<?php
$pageTitle = 'Dashboard'; $pathDepth = 1;
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$userId = (int)$_SESSION['user_id'];
$name   = $_SESSION['user_name'];

$totalStmt = $conn->prepare("SELECT COUNT(*) as t FROM predictions WHERE user_id=?");
$totalStmt->bind_param('i',$userId); $totalStmt->execute();
$total = $totalStmt->get_result()->fetch_assoc()['t'];

$highStmt = $conn->prepare("SELECT COUNT(*) as c FROM predictions WHERE user_id=? AND selection_chance='High'");
$highStmt->bind_param('i',$userId); $highStmt->execute();
$highCount = $highStmt->get_result()->fetch_assoc()['c'];

$lastStmt = $conn->prepare("SELECT selection_chance, probability, created_at FROM predictions WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
$lastStmt->bind_param('i',$userId); $lastStmt->execute();
$last = $lastStmt->get_result()->fetch_assoc();

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
  <div class="container">
    <div class="mb-4 fade-up">
      <h2 class="dash-greeting">Welcome back, <?= htmlspecialchars(explode(' ',$name)[0]) ?> 👋</h2>
      <p class="dash-sub">Your internship readiness dashboard — track your predictions and improve your profile.</p>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up">
          <div class="dash-stat-icon">🔬</div>
          <div><p class="dash-stat-label">Total Predictions</p><p class="dash-stat-value"><?= $total ?></p></div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d1">
          <div class="dash-stat-icon">✅</div>
          <div><p class="dash-stat-label">High Chance Results</p><p class="dash-stat-value" style="color:var(--success)"><?= $highCount ?></p></div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d2">
          <div class="dash-stat-icon">📅</div>
          <div>
            <p class="dash-stat-label">Last Prediction</p>
            <p class="dash-stat-value" style="font-size:1rem"><?= $last ? date('M d', strtotime($last['created_at'])) : 'None' ?></p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d3">
          <div class="dash-stat-icon">📊</div>
          <div>
            <p class="dash-stat-label">Last Probability</p>
            <p class="dash-stat-value" style="font-size:1rem">
              <?= $last ? '<span style="color:var(--blue-lite)">' . $last['probability'] . '%</span>' : '<span style="color:var(--text-muted)">—</span>' ?>
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-6">
        <div class="card-custom fade-up h-100">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:48px;height:48px;background:var(--blue-glow);border:1px solid var(--card-border);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem">💼</div>
            <div><h5 class="fw-700 mb-0">New Prediction</h5><p style="font-size:0.83rem;color:var(--text-muted);margin:0">Check your internship selection chances</p></div>
          </div>
          <p style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;margin-bottom:1.2rem">
            Enter your CGPA, skills, and project count — get instant AI-powered probability of internship selection.
          </p>
          <a href="predict.php" class="btn-prime text-decoration-none"><i class="bi bi-cpu me-2"></i>Start Prediction</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card-custom fade-up fade-up-d1 h-100">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:48px;height:48px;background:var(--blue-glow);border:1px solid var(--card-border);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem">📋</div>
            <div><h5 class="fw-700 mb-0">Prediction History</h5><p style="font-size:0.83rem;color:var(--text-muted);margin:0">Track your progress over time</p></div>
          </div>
          <p style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;margin-bottom:1.2rem">
            See all your previous predictions and monitor how your internship chances have improved.
          </p>
          <a href="history.php" class="btn-outline-prime"><i class="bi bi-clock-history me-2"></i>View History</a>
        </div>
      </div>
      <div class="col-12">
        <div class="card-custom fade-up" style="background:linear-gradient(135deg,rgba(37,99,235,0.08),rgba(10,14,26,0.6));border-color:var(--blue-deep)">
          <div class="row align-items-center">
            <div class="col-md-8">
              <h5 class="fw-700 mb-1"><i class="bi bi-lightbulb text-blue me-2"></i>Pro Tip</h5>
              <p style="font-size:0.85rem;color:var(--text-muted);margin:0;line-height:1.6">
                Students with <strong style="color:var(--blue-lite)">CGPA above 3.0</strong>, at least
                <strong style="color:var(--blue-lite)">3 technical skills</strong>, and
                <strong style="color:var(--blue-lite)">2+ projects</strong> have significantly higher selection rates.
                Keep building your portfolio!
              </p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0"><span style="font-size:3rem">🚀</span></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
