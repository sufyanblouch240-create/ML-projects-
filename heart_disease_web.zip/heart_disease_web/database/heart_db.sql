-- Heart Disease Prediction System Database
-- Run this file in phpMyAdmin or MySQL CLI

CREATE DATABASE IF NOT EXISTS heart_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE heart_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Predictions Table
CREATE TABLE IF NOT EXISTS predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    age INT NOT NULL,
    cholesterol INT NOT NULL,
    blood_pressure INT NOT NULL,
    heart_rate INT NOT NULL,
    chest_pain_type INT NOT NULL,
    risk_level VARCHAR(20) NOT NULL,         -- 'High', 'Medium', 'Low'
    probability DECIMAL(5,2) NOT NULL,        -- e.g. 72.50
    recommendation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample test user (password = test1234)
-- INSERT INTO users (full_name, email, password) VALUES
-- ('Test User', 'test@example.com', '$2y$10$...');
