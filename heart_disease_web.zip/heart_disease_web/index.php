<?php
$pageTitle = 'Home';
$pathDepth = 0;
require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<main>
  <!-- HERO -->
  <section class="hero-section">
    <div class="container">
      <p class="hero-eyebrow fade-up">AI-Powered Cardiology</p>
      <h1 class="hero-title fade-up fade-up-d1">
        Predict Heart Disease<br><em>Before It's Too Late</em>
      </h1>
      <p class="hero-desc fade-up fade-up-d2">
        Use advanced machine learning to assess your cardiovascular risk in minutes.
        Enter simple health metrics — get instant, actionable insights.
      </p>
      <div class="hero-btns fade-up fade-up-d3">
        <?php if (isset($_SESSION['user_id'])): ?>
          <a href="pages/predict.php" class="btn-heart" style="font-size:1rem;padding:0.8rem 2rem">
            <i class="bi bi-activity me-2"></i>Start Prediction
          </a>
          <a href="pages/dashboard.php" class="btn-outline-heart" style="padding:0.75rem 1.8rem">
            Go to Dashboard
          </a>
        <?php else: ?>
          <a href="auth/register.php" class="btn-heart" style="font-size:1rem;padding:0.8rem 2rem">
            <i class="bi bi-person-plus me-2"></i>Get Started Free
          </a>
          <a href="auth/login.php" class="btn-outline-heart" style="padding:0.75rem 1.8rem">
            <i class="bi bi-box-arrow-in-right me-2"></i>Login
          </a>
        <?php endif; ?>
      </div>

      <div class="stat-row fade-up">
        <div class="stat-pill"><strong>~90%</strong> Model Accuracy</div>
        <div class="stat-pill"><strong>5</strong> Health Parameters</div>
        <div class="stat-pill"><strong>&lt;2s</strong> Instant Results</div>
        <div class="stat-pill"><strong>Free</strong> No Cost</div>
      </div>
    </div>
  </section>

  <hr class="divider">

  <!-- HEART DISEASE INFO -->
  <section class="py-5">
    <div class="container">
      <p class="section-label text-center">Why It Matters</p>
      <h2 class="section-title text-center mb-2">Understanding Heart Disease</h2>
      <p class="text-center mb-4" style="color:var(--text-muted);max-width:560px;margin:0 auto 2.5rem">
        Heart disease is the #1 cause of death globally. Early detection saves lives.
      </p>
      <div class="features-grid">
        <div class="feature-card fade-up">
          <div class="feature-icon">🫀</div>
          <h4>What is Heart Disease?</h4>
          <p>A group of conditions affecting heart structure and function — including coronary artery disease, arrhythmias, and heart failure.</p>
        </div>
        <div class="feature-card fade-up fade-up-d1">
          <div class="feature-icon">⚠️</div>
          <h4>Common Risk Factors</h4>
          <p>High blood pressure, high cholesterol, age, chest pain, and elevated heart rate are key predictors analyzed by our model.</p>
        </div>
        <div class="feature-card fade-up fade-up-d2">
          <div class="feature-icon">🤖</div>
          <h4>How AI Helps</h4>
          <p>Our trained ML model uses clinical patterns from thousands of cases to estimate your personal risk level with high accuracy.</p>
        </div>
        <div class="feature-card fade-up fade-up-d3">
          <div class="feature-icon">📋</div>
          <h4>Take Action Early</h4>
          <p>Knowing your risk means you can make lifestyle changes and consult a doctor before symptoms become serious.</p>
        </div>
      </div>
    </div>
  </section>

  <hr class="divider">

  <!-- HOW IT WORKS -->
  <section class="py-5">
    <div class="container">
      <p class="section-label text-center">Simple 3-Step Process</p>
      <h2 class="section-title text-center mb-4">How It Works</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--red-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">1</div>
            <h5 class="fw-700 mb-2">Create Account</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Register for free and login to access the prediction tool securely.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--red-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">2</div>
            <h5 class="fw-700 mb-2">Enter Health Data</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Provide your age, cholesterol, blood pressure, heart rate, and chest pain type.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-custom text-center h-100">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--red-glow);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 1rem">3</div>
            <h5 class="fw-700 mb-2">Get Results</h5>
            <p class="text-muted-custom" style="font-size:0.88rem">Receive your risk level, probability score, and personalised medical recommendations.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<?php require_once 'includes/footer.php'; ?>
