<?php
$pageTitle  = 'Login';
$pathDepth  = 1;
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: ../pages/dashboard.php');
    exit;
}

require_once '../config/db.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id']   = $row['id'];
                $_SESSION['user_name'] = $row['full_name'];
                header('Location: ../pages/dashboard.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'No account found with that email.';
        }
        $stmt->close();
    }
}

require_once '../includes/header.php';
?>

<div class="auth-wrapper">
  <div class="auth-card">
    <p class="auth-logo"><i class="bi bi-heart-pulse-fill me-2"></i>HeartGuard AI</p>
    <p class="auth-subtitle">Sign in to your account</p>

    <?php if ($error): ?>
      <div class="alert-custom alert-error"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="mb-3">
        <label class="form-label-custom">Email Address</label>
        <input type="email" name="email" class="form-control-custom"
               placeholder="you@example.com"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-1">
          <label class="form-label-custom" style="margin-bottom:0">Password</label>
          <a href="forgot_password.php" style="font-size:0.78rem;color:var(--red-lite);text-decoration:none">Forgot password?</a>
        </div>
        <input type="password" name="password" class="form-control-custom" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn-heart w-100" style="padding:0.75rem;font-size:0.95rem">
        <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
      </button>
    </form>

    <p class="text-center mt-3" style="font-size:0.85rem;color:var(--text-muted)">
      Don't have an account?
      <a href="register.php" style="color:var(--red-lite);text-decoration:none;font-weight:600">Register now</a>
    </p>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
