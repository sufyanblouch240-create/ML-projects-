<?php
$pageTitle = 'Forgot Password';
$pathDepth = 1;
session_start();
require_once '../includes/header.php';
?>

<div class="auth-wrapper">
  <div class="auth-card">
    <p class="auth-logo"><i class="bi bi-heart-pulse-fill me-2"></i>HeartGuard AI</p>
    <p class="auth-subtitle">Reset your password</p>

    <div class="alert-custom alert-info">
      <i class="bi bi-info-circle me-2"></i>
      Contact your administrator to reset your password, or check with your supervisor.
    </div>

    <p style="color:var(--text-muted);font-size:0.88rem;line-height:1.6;margin-bottom:1.5rem">
      For this academic project, password reset via email is not implemented.
      Please contact the system admin or re-register with a new account.
    </p>

    <a href="login.php" class="btn-outline-heart d-block text-center">
      <i class="bi bi-arrow-left me-2"></i>Back to Login
    </a>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
