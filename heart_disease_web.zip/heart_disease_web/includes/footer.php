  <footer class="footer-main">
    <div class="container">
      <p>
        <i class="bi bi-heart-pulse-fill text-red me-1"></i>
        <strong>HeartGuard AI</strong> &mdash; Heart Disease Prediction System &nbsp;|&nbsp;
        Final Year Project &nbsp;|&nbsp;
        Built with ❤️ by <strong>Abdul Rehman</strong> &amp; <strong>M Sufyan Khan</strong>
      </p>
      <p class="mt-1" style="font-size:0.78rem;color:#555">
        Supervisor: Dr. M Salman Iqbal &nbsp;|&nbsp; FA23-BCS &nbsp;|&nbsp; 2023–2027
      </p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= isset($pathDepth) ? str_repeat('../', $pathDepth) : '' ?>assets/js/main.js"></script>
</body>
</html>
