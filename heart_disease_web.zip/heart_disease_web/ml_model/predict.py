"""
predict.py
----------
Called by predict_api.php via shell_exec.
Receives: age,cholesterol,blood_pressure,heart_rate,chest_pain_type (as CSV string)
Returns : JSON { "probability": float, "risk_level": str }

Usage:
    python predict.py "45,220,130,140,1"
"""

import sys
import json
import os
import pickle
import numpy as np

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'heart_model.pkl')


def predict(age, chol, bp, hr, cp):
    if not os.path.exists(MODEL_PATH):
        return {"error": "Model not found. Run train_model.py first."}

    with open(MODEL_PATH, 'rb') as f:
        bundle = pickle.load(f)

    model  = bundle['model']
    scaler = bundle['scaler']

    # Feature order must match training: age, chol, trestbps, thalach, cp
    features = np.array([[age, chol, bp, hr, cp]], dtype=float)
    features = scaler.transform(features)

    probability = float(model.predict_proba(features)[0][1]) * 100  # class 1 = disease
    risk_level  = 'High' if probability >= 65 else ('Medium' if probability >= 40 else 'Low')

    return {
        "probability": round(probability, 2),
        "risk_level":  risk_level
    }


if __name__ == '__main__':
    try:
        if len(sys.argv) < 2:
            raise ValueError("No input provided.")

        parts = sys.argv[1].split(',')
        if len(parts) != 5:
            raise ValueError("Expected 5 comma-separated values.")

        age, chol, bp, hr, cp = [float(p.strip()) for p in parts]
        result = predict(int(age), int(chol), int(bp), int(hr), int(cp))
        print(json.dumps(result))

    except Exception as e:
        print(json.dumps({"error": str(e)}))
