"""
train_model.py
--------------
Trains a Random Forest classifier on the heart disease dataset
and saves the model as heart_model.pkl.

Run once:
    python train_model.py
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import pickle
import os

# ── Load dataset ──────────────────────────────────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
CSV_PATH  = os.path.join(BASE_DIR, 'dataset', 'heart.csv')
MODEL_OUT = os.path.join(BASE_DIR, 'heart_model.pkl')

print(f"[*] Loading dataset from: {CSV_PATH}")
df = pd.read_csv(CSV_PATH)
print(f"[*] Dataset shape: {df.shape}")
print(df.head())

# ── Feature selection ─────────────────────────────────────────────────────────
# We use only: age, chol, trestbps, thalach, cp
# (maps to our web form inputs)
feature_cols = ['age', 'chol', 'trestbps', 'thalach', 'cp']
target_col   = 'target'  # 0 = no disease, 1 = disease

# Ensure columns exist
for col in feature_cols + [target_col]:
    if col not in df.columns:
        raise ValueError(f"Column '{col}' not found in dataset. Available: {list(df.columns)}")

X = df[feature_cols]
y = df[target_col]

print(f"[*] Features: {feature_cols}")
print(f"[*] Class distribution:\n{y.value_counts()}")

# ── Train/test split ──────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ── Scale features ────────────────────────────────────────────────────────────
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

# ── Train model ───────────────────────────────────────────────────────────────
print("[*] Training Random Forest Classifier...")
model = RandomForestClassifier(
    n_estimators=200,
    max_depth=8,
    random_state=42,
    n_jobs=-1
)
model.fit(X_train, y_train)

# ── Evaluate ──────────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
acc    = accuracy_score(y_test, y_pred)
print(f"\n[✓] Accuracy: {acc * 100:.2f}%")
print("\n[*] Classification Report:")
print(classification_report(y_test, y_pred))

# ── Save model + scaler ───────────────────────────────────────────────────────
with open(MODEL_OUT, 'wb') as f:
    pickle.dump({'model': model, 'scaler': scaler}, f)

print(f"\n[✓] Model saved to: {MODEL_OUT}")
