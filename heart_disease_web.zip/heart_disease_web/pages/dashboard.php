<?php
$pageTitle = 'Dashboard';
$pathDepth = 1;
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../config/db.php';

$userId = $_SESSION['user_id'];
$name   = $_SESSION['user_name'];

// Stats
$totalStmt = $conn->prepare("SELECT COUNT(*) as total FROM predictions WHERE user_id = ?");
$totalStmt->bind_param('i', $userId);
$totalStmt->execute();
$totalRow   = $totalStmt->get_result()->fetch_assoc();
$totalPreds = $totalRow['total'];

$highStmt = $conn->prepare("SELECT COUNT(*) as cnt FROM predictions WHERE user_id = ? AND risk_level = 'High'");
$highStmt->bind_param('i', $userId);
$highStmt->execute();
$highRow  = $highStmt->get_result()->fetch_assoc();
$highRisk = $highRow['cnt'];

$lastStmt = $conn->prepare("SELECT risk_level, created_at FROM predictions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
$lastStmt->bind_param('i', $userId);
$lastStmt->execute();
$lastResult = $lastStmt->get_result()->fetch_assoc();

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="page-wrapper">
  <div class="container">

    <!-- Greeting -->
    <div class="mb-4 fade-up">
      <h2 class="dash-greeting">Welcome back, <?= htmlspecialchars(explode(' ', $name)[0]) ?> 👋</h2>
      <p class="dash-sub">Your heart health dashboard — track predictions and stay informed.</p>
    </div>

    <!-- Stats Row -->
    <div class="row g-3 mb-4">
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up">
          <div class="dash-stat-icon">🔬</div>
          <div>
            <p class="dash-stat-label">Total Predictions</p>
            <p class="dash-stat-value"><?= $totalPreds ?></p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d1">
          <div class="dash-stat-icon">⚠️</div>
          <div>
            <p class="dash-stat-label">High Risk Results</p>
            <p class="dash-stat-value" style="color:var(--red-mid)"><?= $highRisk ?></p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d2">
          <div class="dash-stat-icon">📅</div>
          <div>
            <p class="dash-stat-label">Last Prediction</p>
            <p class="dash-stat-value" style="font-size:1rem">
              <?= $lastResult ? date('M d', strtotime($lastResult['created_at'])) : 'None' ?>
            </p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-lg-3">
        <div class="dash-stat-card fade-up fade-up-d3">
          <div class="dash-stat-icon">📊</div>
          <div>
            <p class="dash-stat-label">Last Risk Level</p>
            <p class="dash-stat-value" style="font-size:1rem">
              <?php if ($lastResult):
                $c = $lastResult['risk_level'] === 'High' ? 'var(--red-mid)' : ($lastResult['risk_level'] === 'Medium' ? 'var(--warning)' : 'var(--success)');
                echo "<span style='color:$c'>" . htmlspecialchars($lastResult['risk_level']) . "</span>";
              else: echo '<span style="color:var(--text-muted)">—</span>';
              endif; ?>
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-3">
      <div class="col-md-6">
        <div class="card-custom fade-up h-100">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:48px;height:48px;background:var(--red-glow);border:1px solid var(--card-border);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem">💓</div>
            <div>
              <h5 class="fw-700 mb-0">New Prediction</h5>
              <p style="font-size:0.83rem;color:var(--text-muted);margin:0">Check your heart disease risk now</p>
            </div>
          </div>
          <p style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;margin-bottom:1.2rem">
            Enter your health parameters and let our AI model assess your cardiovascular risk instantly.
          </p>
          <a href="predict.php" class="btn-heart d-inline-block text-decoration-none">
            <i class="bi bi-activity me-2"></i>Start Prediction
          </a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card-custom fade-up fade-up-d1 h-100">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:48px;height:48px;background:var(--red-glow);border:1px solid var(--card-border);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem">📋</div>
            <div>
              <h5 class="fw-700 mb-0">Prediction History</h5>
              <p style="font-size:0.83rem;color:var(--text-muted);margin:0">View all your past results</p>
            </div>
          </div>
          <p style="font-size:0.88rem;color:var(--text-muted);line-height:1.6;margin-bottom:1.2rem">
            Track how your cardiovascular risk has changed over time with your complete prediction history.
          </p>
          <a href="history.php" class="btn-outline-heart d-inline-block">
            <i class="bi bi-clock-history me-2"></i>View History
          </a>
        </div>
      </div>

      <!-- Info Card -->
      <div class="col-12">
        <div class="card-custom fade-up" style="background:linear-gradient(135deg,rgba(192,57,43,0.08),rgba(13,15,20,0.6));border-color:var(--red-deep)">
          <div class="row align-items-center">
            <div class="col-md-8">
              <h5 class="fw-700 mb-1"><i class="bi bi-shield-heart text-red me-2"></i>Medical Disclaimer</h5>
              <p style="font-size:0.85rem;color:var(--text-muted);margin:0;line-height:1.6">
                This tool is for educational and informational purposes only. Results should not replace
                professional medical diagnosis. Always consult a qualified healthcare provider for medical advice.
              </p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
              <span style="font-size:3rem">🩺</span>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
