<?php
$pageTitle = 'Prediction History';
$pathDepth = 1;
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../config/db.php';

$userId = $_SESSION['user_id'];
$stmt   = $conn->prepare("
    SELECT id, age, cholesterol, blood_pressure, heart_rate, chest_pain_type,
           risk_level, probability, created_at
    FROM predictions
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$results = $stmt->get_result();
$rows    = $results->fetch_all(MYSQLI_ASSOC);

$cpLabels = ['Typical Angina','Atypical Angina','Non-anginal','Asymptomatic'];

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="page-wrapper">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center mb-4 fade-up">
      <div>
        <h2 style="font-family:'DM Serif Display',serif;font-size:2rem">Prediction History</h2>
        <p style="color:var(--text-muted);font-size:0.9rem;margin-top:0.2rem">All your previous heart risk assessments</p>
      </div>
      <a href="predict.php" class="btn-heart text-decoration-none">
        <i class="bi bi-plus-lg me-2"></i>New Prediction
      </a>
    </div>

    <?php if (empty($rows)): ?>
      <div class="card-custom text-center py-5 fade-up">
        <div style="font-size:3rem;margin-bottom:1rem">🔬</div>
        <h5 class="fw-700 mb-2">No Predictions Yet</h5>
        <p style="color:var(--text-muted);font-size:0.9rem;margin-bottom:1.5rem">You haven't run any heart disease predictions yet.</p>
        <a href="predict.php" class="btn-heart text-decoration-none">
          <i class="bi bi-activity me-2"></i>Start Your First Prediction
        </a>
      </div>

    <?php else: ?>
      <!-- Stats bar -->
      <div class="row g-3 mb-4">
        <?php
          $total  = count($rows);
          $high   = count(array_filter($rows, fn($r) => $r['risk_level'] === 'High'));
          $med    = count(array_filter($rows, fn($r) => $r['risk_level'] === 'Medium'));
          $low    = count(array_filter($rows, fn($r) => $r['risk_level'] === 'Low'));
          $avgP   = round(array_sum(array_column($rows, 'probability')) / $total, 1);
        ?>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up"><div class="dash-stat-icon">📊</div><div><p class="dash-stat-label">Total</p><p class="dash-stat-value"><?= $total ?></p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d1"><div class="dash-stat-icon">🔴</div><div><p class="dash-stat-label">High Risk</p><p class="dash-stat-value" style="color:var(--red-mid)"><?= $high ?></p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d2"><div class="dash-stat-icon">🟡</div><div><p class="dash-stat-label">Medium Risk</p><p class="dash-stat-value" style="color:var(--warning)"><?= $med ?></p></div></div></div>
        <div class="col-6 col-md-3"><div class="dash-stat-card fade-up fade-up-d3"><div class="dash-stat-icon">📈</div><div><p class="dash-stat-label">Avg Probability</p><p class="dash-stat-value"><?= $avgP ?>%</p></div></div></div>
      </div>

      <!-- Table -->
      <div class="card-custom fade-up" style="overflow-x:auto">
        <table class="hist-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Date</th>
              <th>Age</th>
              <th>Cholesterol</th>
              <th>BP</th>
              <th>HR</th>
              <th>Chest Pain</th>
              <th>Risk</th>
              <th>Probability</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $row): ?>
              <?php
                $badgeClass = $row['risk_level'] === 'High' ? 'risk-high' : ($row['risk_level'] === 'Medium' ? 'risk-medium' : 'risk-low');
              ?>
              <tr>
                <td style="color:var(--text-muted)"><?= $i + 1 ?></td>
                <td><?= date('M d, Y', strtotime($row['created_at'])) ?><br><small style="color:var(--text-muted)"><?= date('H:i', strtotime($row['created_at'])) ?></small></td>
                <td><?= $row['age'] ?> yrs</td>
                <td><?= $row['cholesterol'] ?> mg/dL</td>
                <td><?= $row['blood_pressure'] ?> mmHg</td>
                <td><?= $row['heart_rate'] ?> bpm</td>
                <td><?= $cpLabels[$row['chest_pain_type']] ?? '—' ?></td>
                <td><span class="risk-badge <?= $badgeClass ?>"><?= htmlspecialchars($row['risk_level']) ?></span></td>
                <td class="fw-700"><?= $row['probability'] ?>%</td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
