<?php
$pageTitle = 'Heart Risk Prediction';
$pathDepth = 1;
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="page-wrapper">
  <div class="container">
    <div class="predict-header fade-up">
      <h2>Heart Risk Prediction</h2>
      <p>Fill in your health parameters below — the AI model will assess your cardiovascular risk.</p>
    </div>

    <form method="POST" action="../api/predict_api.php" id="predictForm">
      <div class="row g-4">

        <!-- LEFT COLUMN -->
        <div class="col-lg-7">

          <!-- Age -->
          <div class="card-custom mb-3 fade-up">
            <span class="step-badge">Parameter 1 of 5</span>
            <label class="form-label-custom">Age (years)</label>
            <input type="range" name="age" id="ageRange" min="20" max="100" value="45"
                   oninput="document.getElementById('ageVal').textContent=this.value">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">20 yrs</span>
              <span class="range-val" id="ageVal">45</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">100 yrs</span>
            </div>
          </div>

          <!-- Cholesterol -->
          <div class="card-custom mb-3 fade-up fade-up-d1">
            <span class="step-badge">Parameter 2 of 5</span>
            <label class="form-label-custom">Serum Cholesterol (mg/dL)</label>
            <input type="range" name="cholesterol" id="cholRange" min="100" max="600" value="250"
                   oninput="document.getElementById('cholVal').textContent=this.value">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">100</span>
              <span class="range-val" id="cholVal">250</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">600 mg/dL</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:0.5rem"><i class="bi bi-info-circle me-1"></i>Normal: &lt;200 mg/dL | Borderline: 200–239 | High: ≥240</p>
          </div>

          <!-- Blood Pressure -->
          <div class="card-custom mb-3 fade-up fade-up-d2">
            <span class="step-badge">Parameter 3 of 5</span>
            <label class="form-label-custom">Resting Blood Pressure (mmHg)</label>
            <input type="range" name="blood_pressure" id="bpRange" min="80" max="220" value="120"
                   oninput="document.getElementById('bpVal').textContent=this.value">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">80</span>
              <span class="range-val" id="bpVal">120</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">220 mmHg</span>
            </div>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:0.5rem"><i class="bi bi-info-circle me-1"></i>Normal: &lt;120 | Elevated: 120–129 | High: ≥130</p>
          </div>

          <!-- Heart Rate -->
          <div class="card-custom mb-3 fade-up fade-up-d3">
            <span class="step-badge">Parameter 4 of 5</span>
            <label class="form-label-custom">Maximum Heart Rate Achieved (bpm)</label>
            <input type="range" name="heart_rate" id="hrRange" min="60" max="220" value="140"
                   oninput="document.getElementById('hrVal').textContent=this.value">
            <div class="d-flex justify-content-between align-items-center mt-2">
              <span style="font-size:0.8rem;color:var(--text-muted)">60</span>
              <span class="range-val" id="hrVal">140</span>
              <span style="font-size:0.8rem;color:var(--text-muted)">220 bpm</span>
            </div>
          </div>

          <!-- Chest Pain -->
          <div class="card-custom mb-3 fade-up">
            <span class="step-badge">Parameter 5 of 5</span>
            <label class="form-label-custom">Chest Pain Type</label>
            <select name="chest_pain_type" class="form-control-custom" required>
              <option value="">— Select Type —</option>
              <option value="0">Type 0 — Typical Angina</option>
              <option value="1">Type 1 — Atypical Angina</option>
              <option value="2">Type 2 — Non-anginal Pain</option>
              <option value="3">Type 3 — Asymptomatic</option>
            </select>
            <p style="font-size:0.78rem;color:var(--text-muted);margin-top:0.5rem"><i class="bi bi-info-circle me-1"></i>Higher type numbers typically indicate less severe symptoms</p>
          </div>

        </div>

        <!-- RIGHT COLUMN: Summary + Submit -->
        <div class="col-lg-5">
          <div class="card-custom fade-up" style="position:sticky;top:90px">
            <h6 class="fw-700 mb-3" style="font-size:0.9rem;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted)">
              <i class="bi bi-clipboard2-pulse me-2 text-red"></i>Summary
            </h6>
            <div id="summaryBox" style="display:flex;flex-direction:column;gap:0.6rem;margin-bottom:1.5rem">
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">Age</span>
                <span class="fw-700" id="s-age">45 yrs</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">Cholesterol</span>
                <span class="fw-700" id="s-chol">250 mg/dL</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">Blood Pressure</span>
                <span class="fw-700" id="s-bp">120 mmHg</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem;border-bottom:1px solid var(--card-border);padding-bottom:0.5rem">
                <span style="color:var(--text-muted)">Heart Rate</span>
                <span class="fw-700" id="s-hr">140 bpm</span>
              </div>
              <div class="d-flex justify-content-between" style="font-size:0.88rem">
                <span style="color:var(--text-muted)">Chest Pain</span>
                <span class="fw-700" id="s-cp">—</span>
              </div>
            </div>

            <button type="submit" class="btn-heart w-100 mb-2" id="submitBtn" style="padding:0.85rem;font-size:1rem">
              <i class="bi bi-cpu me-2"></i>Run AI Prediction
            </button>
            <p style="font-size:0.75rem;color:var(--text-muted);text-align:center;line-height:1.5">
              Results are generated by a machine learning model.<br>Not a substitute for medical advice.
            </p>
          </div>
        </div>

      </div>
    </form>
  </div>
</div>

<script>
// Live summary update
const cpLabels = ['Typical Angina','Atypical Angina','Non-anginal Pain','Asymptomatic'];

function updateSummary() {
  document.getElementById('s-age').textContent  = document.getElementById('ageRange').value + ' yrs';
  document.getElementById('s-chol').textContent = document.getElementById('cholRange').value + ' mg/dL';
  document.getElementById('s-bp').textContent   = document.getElementById('bpRange').value + ' mmHg';
  document.getElementById('s-hr').textContent   = document.getElementById('hrRange').value + ' bpm';
  const cp = document.querySelector('select[name="chest_pain_type"]').value;
  document.getElementById('s-cp').textContent = cp !== '' ? 'Type ' + cp + ' — ' + cpLabels[cp] : '—';
}

['ageRange','cholRange','bpRange','hrRange'].forEach(id => {
  document.getElementById(id).addEventListener('input', updateSummary);
});
document.querySelector('select[name="chest_pain_type"]').addEventListener('change', updateSummary);

// Submit button loading state
document.getElementById('predictForm').addEventListener('submit', function() {
  const btn = document.getElementById('submitBtn');
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Analyzing...';
  btn.disabled = true;
});
</script>

<?php require_once '../includes/footer.php'; ?>
