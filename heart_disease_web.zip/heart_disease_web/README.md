# HeartGuard AI — Heart Disease Prediction System
**Final Year Project | FA23-BCS | 2023–2027**
**Abdul Rehman (FA23-BCS-157) | M Sufyan Khan (FA23-BCS-166)**
**Supervisor: Dr. M Salman Iqbal**

---

## 📁 Project Structure
```
heart_disease_web/
├── assets/css/style.css        ← All styles (dark medical theme)
├── assets/js/main.js           ← JavaScript helpers
├── config/db.php               ← MySQL connection
├── database/heart_db.sql       ← Run this to create DB
├── includes/                   ← header, navbar, footer
├── auth/                       ← login, register, logout
├── pages/                      ← dashboard, predict, result, history
├── ml_model/
│   ├── dataset/heart.csv       ← Place your dataset here
│   ├── train_model.py          ← Run once to train
│   ├── predict.py              ← Called automatically by PHP
│   └── heart_model.pkl         ← Generated after training
├── api/predict_api.php         ← PHP → Python bridge
├── index.php                   ← Home page
└── .htaccess                   ← Security rules
```

---

## ⚙️ Setup Instructions

### 1. Requirements
- XAMPP / WAMP / LAMP (Apache + PHP 8.0+ + MySQL)
- Python 3.8+
- pip packages: `pandas scikit-learn numpy`

### 2. Install Python Packages
```bash
pip install pandas scikit-learn numpy
```

### 3. Create Database
- Open phpMyAdmin
- Create database: `heart_db`
- Import: `database/heart_db.sql`

### 4. Configure DB (if needed)
Edit `config/db.php` — change `DB_USER` / `DB_PASS` if not using default root/blank.

### 5. Add Dataset
Place your `heart.csv` in `ml_model/dataset/`.
The CSV must have columns: `age, chol, trestbps, thalach, cp, target`

Download from: https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset

### 6. Train the Model
```bash
cd ml_model
python train_model.py
```
This creates `heart_model.pkl`.

### 7. Run the Website
Place the entire `heart_disease_web/` folder in:
- XAMPP: `C:/xampp/htdocs/`
- WAMP: `C:/wamp/www/`

Visit: `http://localhost/heart_disease_web/`

---

## 📄 Pages
| Page | URL |
|------|-----|
| Home | `/index.php` |
| Register | `/auth/register.php` |
| Login | `/auth/login.php` |
| Dashboard | `/pages/dashboard.php` |
| Prediction | `/pages/predict.php` |
| Result | `/pages/result.php` |
| History | `/pages/history.php` |

---

## 🤖 ML Model
- **Algorithm:** Random Forest Classifier
- **Features:** Age, Cholesterol, Blood Pressure, Max Heart Rate, Chest Pain Type
- **Dataset:** UCI Heart Disease / Kaggle heart.csv (~300 rows)
- **Accuracy:** ~85–90%
- **Fallback:** If model not found, PHP uses a rule-based heuristic automatically

---

## ⚠️ Disclaimer
This project is for educational purposes only. Results do not constitute medical advice.
