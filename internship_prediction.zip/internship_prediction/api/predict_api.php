<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ../pages/predict.php'); exit; }

require_once '../config/db.php';

$userId        = (int)$_SESSION['user_id'];
$cgpa          = (float)($_POST['cgpa'] ?? 0);
$skillsArr     = $_POST['skills'] ?? [];
$projectsCount = (int)($_POST['projects_count'] ?? 0);
$skillsList    = implode(', ', array_map('htmlspecialchars', $skillsArr));
$skillsScore   = count($skillsArr);

// ── Call Python ML (3 algorithms) ────────────────────────────────────────────
$pythonPath = 'python';   // use 'python3' on Linux/Mac
$scriptPath = __DIR__ . '/../ml_model/predict.py';
$input      = escapeshellarg("$cgpa,$skillsScore,$projectsCount");
$output     = shell_exec("$pythonPath $scriptPath $input 2>&1");
$mlResult   = json_decode(trim($output), true);

// ── Fallback heuristic if ML fails ───────────────────────────────────────────
function calcScore($cgpa, $skillsScore, $projectsCount) {
    $score  = ($cgpa / 4.0) * 40;
    $score += min(($skillsScore / 5) * 35, 35);
    $score += min(($projectsCount / 5) * 25, 25);
    return min(98, max(5, round($score + rand(-3, 3))));
}

function chanceLabel($prob) {
    return $prob >= 65 ? 'High' : ($prob >= 40 ? 'Medium' : 'Low');
}

if (!$mlResult || isset($mlResult['error']) || !isset($mlResult['ensemble'])) {
    // Fallback: simulate 3 slightly different heuristic scores
    $rfProb   = (float)calcScore($cgpa, $skillsScore, $projectsCount);
    $lrProb   = (float)calcScore($cgpa, $skillsScore, $projectsCount);
    $knnProb  = (float)calcScore($cgpa, $skillsScore, $projectsCount);
    $avgProb  = round(($rfProb + $lrProb + $knnProb) / 3, 2);

    $rfChance  = chanceLabel($rfProb);
    $lrChance  = chanceLabel($lrProb);
    $knnChance = chanceLabel($knnProb);

    $votes = [$rfChance, $lrChance, $knnChance];
    $majority = array_search(max(array_count_values($votes)), array_count_values($votes));

    $mlResult = [
        'random_forest'       => ['probability' => $rfProb,  'selection_chance' => $rfChance],
        'logistic_regression' => ['probability' => $lrProb,  'selection_chance' => $lrChance],
        'knn'                 => ['probability' => $knnProb, 'selection_chance' => $knnChance],
        'ensemble'            => [
            'probability'     => $avgProb,
            'selection_chance'=> $majority,
            'votes'           => ['High' => 0, 'Medium' => 0, 'Low' => 0]
        ]
    ];
}

// ── Extract individual results ────────────────────────────────────────────────
$rfProb    = (float)$mlResult['random_forest']['probability'];
$rfChance  = $mlResult['random_forest']['selection_chance'];
$lrProb    = (float)$mlResult['logistic_regression']['probability'];
$lrChance  = $mlResult['logistic_regression']['selection_chance'];
$knnProb   = (float)$mlResult['knn']['probability'];
$knnChance = $mlResult['knn']['selection_chance'];

// ── Ensemble (final decision) ─────────────────────────────────────────────────
$probability     = (float)$mlResult['ensemble']['probability'];
$selectionChance = $mlResult['ensemble']['selection_chance'];
$votes           = $mlResult['ensemble']['votes'] ?? [];

// ── Build recommendations ─────────────────────────────────────────────────────
$recommendations = [];

if ($selectionChance === 'High') {
    $recommendations[] = 'Your profile is competitive — start applying to top internships now!';
    $recommendations[] = 'Prepare a strong resume highlighting your projects and skills.';
    $recommendations[] = 'Practice DSA and system design for technical interviews.';
    $recommendations[] = 'Build a GitHub portfolio to showcase your work to recruiters.';
} elseif ($selectionChance === 'Medium') {
    $recommendations[] = 'You have potential — focus on adding 1-2 more technical skills.';
    $recommendations[] = 'Complete at least one industry-relevant project before applying.';
    $recommendations[] = 'Consider getting certifications (Coursera, Google, AWS) to boost your profile.';
    $recommendations[] = 'Practice LeetCode easy/medium problems for coding interviews.';
} else {
    $recommendations[] = 'Focus on improving your CGPA — aim for at least 2.8+.';
    $recommendations[] = 'Start learning in-demand skills: Python, SQL, or JavaScript.';
    $recommendations[] = 'Work on at least 1-2 small projects to build your portfolio.';
    $recommendations[] = 'Join university tech clubs and participate in hackathons.';
    $recommendations[] = 'Apply for beginner-friendly internships and open source contributions.';
}

if ($cgpa < 2.5)         $recommendations[] = 'Low CGPA is a significant barrier — focus on academics this semester.';
if ($skillsScore === 0)  $recommendations[] = 'No skills selected — start with Python or JavaScript as your first skill.';
if ($skillsScore >= 5)   $recommendations[] = 'Great skills portfolio! Make sure you have projects demonstrating each skill.';
if ($projectsCount >= 5) $recommendations[] = 'Excellent project count! Host them on GitHub with proper READMEs.';
if ($projectsCount < 2)  $recommendations[] = 'Build at least 2 projects — even small ones show initiative to recruiters.';

// ── Save to DB ────────────────────────────────────────────────────────────────
// First ensure new columns exist, add them if missing
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS rf_probability DECIMAL(5,2)");
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS rf_chance VARCHAR(20)");
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS lr_probability DECIMAL(5,2)");
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS lr_chance VARCHAR(20)");
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS knn_probability DECIMAL(5,2)");
$conn->query("ALTER TABLE predictions ADD COLUMN IF NOT EXISTS knn_chance VARCHAR(20)");

$stmt = $conn->prepare("
    INSERT INTO predictions
        (user_id, cgpa, skills_score, skills_list, projects_count,
         selection_chance, probability,
         rf_probability, rf_chance,
         lr_probability, lr_chance,
         knn_probability, knn_chance,
         recommendation)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param(
    'idisiddsdsdsss',
    $userId, $cgpa, $skillsScore, $skillsList, $projectsCount,
    $selectionChance, $probability,
    $rfProb, $rfChance,
    $lrProb, $lrChance,
    $knnProb, $knnChance,
    $recText
);
$stmt->bind_param(
    'idisiddsdsdsss',
    $userId, $cgpa, $skillsScore, $skillsList, $projectsCount,
    $selectionChance, $probability,
    $rfProb, $rfChance,
    $lrProb, $lrChance,
    $knnProb, $knnChance,
    $recText
);
$stmt->execute();
$stmt->close();

// ── Store result in session ───────────────────────────────────────────────────
$_SESSION['last_result'] = [
    'selection_chance' => $selectionChance,
    'probability'      => round($probability, 2),
    'cgpa'             => $cgpa,
    'skills_list'      => $skillsList,
    'projects_count'   => $projectsCount,
    'recommendations'  => $recommendations,
    'algorithms'       => [
        ['name' => 'Random Forest',       'short' => 'RF',  'prob' => round($rfProb, 2),  'chance' => $rfChance],
        ['name' => 'Logistic Regression', 'short' => 'LR',  'prob' => round($lrProb, 2),  'chance' => $lrChance],
        ['name' => 'K-Nearest Neighbors', 'short' => 'KNN', 'prob' => round($knnProb, 2), 'chance' => $knnChance],
    ],
    'votes' => $votes,
];

header('Location: ../pages/result.php');
exit;
?>
