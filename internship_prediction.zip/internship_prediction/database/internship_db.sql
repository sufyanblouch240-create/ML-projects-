-- Internship Selection Prediction System (3 Algorithms)
-- Import this in phpMyAdmin

CREATE DATABASE IF NOT EXISTS internship_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE internship_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    cgpa DECIMAL(4,2) NOT NULL,
    skills_score INT NOT NULL,
    skills_list VARCHAR(500),
    projects_count INT NOT NULL,
    -- Ensemble (final) result
    selection_chance VARCHAR(20) NOT NULL,
    probability DECIMAL(5,2) NOT NULL,
    -- Individual algorithm results
    rf_probability DECIMAL(5,2),
    rf_chance VARCHAR(20),
    lr_probability DECIMAL(5,2),
    lr_chance VARCHAR(20),
    knn_probability DECIMAL(5,2),
    knn_chance VARCHAR(20),
    -- Recommendations
    recommendation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
