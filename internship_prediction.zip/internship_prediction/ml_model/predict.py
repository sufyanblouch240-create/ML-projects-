"""
predict.py — Internship Selection Prediction (3 Algorithms)
Usage: python predict.py "3.5,4,3"
       (cgpa, skills_count, projects_count)
Returns JSON with predictions from all 3 algorithms + ensemble result
"""

import sys, json, os, pickle
import numpy as np

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'internship_model.pkl')

def get_chance_label(prob):
    """Convert probability (0-100) to chance label."""
    if prob >= 65:   return 'High'
    elif prob >= 40: return 'Medium'
    else:            return 'Low'

def predict(cgpa, skills_count, projects):
    if not os.path.exists(MODEL_PATH):
        return {"error": "Model not found. Run train_model.py first."}

    with open(MODEL_PATH, 'rb') as f:
        bundle = pickle.load(f)

    scaler = bundle['scaler']
    features = np.array([[cgpa, skills_count, projects]], dtype=float)
    features_sc = scaler.transform(features)

    results = {}

    # ── 1. Random Forest ──────────────────────────────────────────────────────
    rf_model = bundle['random_forest']
    rf_prob  = float(rf_model.predict_proba(features_sc)[0][1]) * 100
    results['random_forest'] = {
        'probability':     round(rf_prob, 2),
        'selection_chance': get_chance_label(rf_prob),
        'label':           'Random Forest',
        'short':           'RF'
    }

    # ── 2. Logistic Regression ────────────────────────────────────────────────
    lr_model = bundle['logistic_regression']
    lr_prob  = float(lr_model.predict_proba(features_sc)[0][1]) * 100
    results['logistic_regression'] = {
        'probability':     round(lr_prob, 2),
        'selection_chance': get_chance_label(lr_prob),
        'label':           'Logistic Regression',
        'short':           'LR'
    }

    # ── 3. KNN ────────────────────────────────────────────────────────────────
    knn_model = bundle['knn']
    knn_prob  = float(knn_model.predict_proba(features_sc)[0][1]) * 100
    results['knn'] = {
        'probability':     round(knn_prob, 2),
        'selection_chance': get_chance_label(knn_prob),
        'label':           'K-Nearest Neighbors',
        'short':           'KNN'
    }

    # ── Ensemble: average probability + majority vote ─────────────────────────
    avg_prob     = round((rf_prob + lr_prob + knn_prob) / 3, 2)
    votes_high   = sum(1 for r in results.values() if r['selection_chance'] == 'High')
    votes_medium = sum(1 for r in results.values() if r['selection_chance'] == 'Medium')
    votes_low    = sum(1 for r in results.values() if r['selection_chance'] == 'Low')

    # Majority vote
    if votes_high >= 2:   majority = 'High'
    elif votes_medium >= 2: majority = 'Medium'
    else:                 majority = 'Low'

    results['ensemble'] = {
        'probability':     avg_prob,
        'selection_chance': majority,
        'votes':           {'High': votes_high, 'Medium': votes_medium, 'Low': votes_low}
    }

    return results

if __name__ == '__main__':
    try:
        if len(sys.argv) < 2:
            raise ValueError("No input.")
        parts = sys.argv[1].split(',')
        if len(parts) != 3:
            raise ValueError("Expected 3 values: cgpa,skills_count,projects")
        cgpa, skills, projects = float(parts[0]), int(parts[1]), int(parts[2])
        print(json.dumps(predict(cgpa, skills, projects)))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
