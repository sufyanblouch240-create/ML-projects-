"""
train_model.py — Internship Selection Prediction (3 Algorithms)
---------------------------------------------------------------
Trains 3 classifiers on internship dataset:
  1. Random Forest
  2. Logistic Regression
  3. K-Nearest Neighbors (KNN)

Run once: python train_model.py
"""

import pandas as pd
import numpy as np
import pickle, os

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
CSV_PATH   = os.path.join(BASE_DIR, 'dataset', 'internship.csv')
MODEL_PATH = os.path.join(BASE_DIR, 'internship_model.pkl')

# ── Generate synthetic dataset if CSV not found ────────────────────────────────
if not os.path.exists(CSV_PATH):
    print("[*] Dataset not found — generating synthetic dataset (1000 rows)...")
    np.random.seed(42)
    n = 1000

    cgpa          = np.round(np.random.uniform(1.5, 4.0, n), 2)
    skills_count  = np.random.randint(0, 10, n)
    projects      = np.random.randint(0, 15, n)

    score = (cgpa / 4.0) * 0.4 + (skills_count / 10) * 0.35 + (projects / 15) * 0.25
    noise = np.random.normal(0, 0.08, n)
    prob  = np.clip(score + noise, 0, 1)
    selected = (prob >= 0.5).astype(int)

    df = pd.DataFrame({'cgpa': cgpa, 'skills_count': skills_count, 'projects': projects, 'selected': selected})
    os.makedirs(os.path.dirname(CSV_PATH), exist_ok=True)
    df.to_csv(CSV_PATH, index=False)
    print(f"[✓] Synthetic dataset saved: {CSV_PATH}")
else:
    df = pd.read_csv(CSV_PATH)
    print(f"[*] Loaded dataset: {CSV_PATH} — {df.shape[0]} rows")

# ── Features & target ─────────────────────────────────────────────────────────
feature_cols = ['cgpa', 'skills_count', 'projects']
target_col   = 'selected'

df.columns = df.columns.str.strip().str.lower()
for c in feature_cols + [target_col]:
    if c not in df.columns:
        raise ValueError(f"Column '{c}' not found. Available: {list(df.columns)}")

X = df[feature_cols]
y = df[target_col]

print(f"[*] Class distribution:\n{y.value_counts()}")

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler     = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# ── Define 3 algorithms ───────────────────────────────────────────────────────
algorithms = {
    'random_forest':       RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42, n_jobs=-1),
    'logistic_regression': LogisticRegression(max_iter=1000, random_state=42, C=1.0),
    'knn':                 KNeighborsClassifier(n_neighbors=7, metric='euclidean'),
}

trained_models = {}
print("\n" + "="*50)
for name, clf in algorithms.items():
    print(f"\n[*] Training: {name.replace('_', ' ').title()}...")
    clf.fit(X_train_sc, y_train)
    y_pred = clf.predict(X_test_sc)
    acc    = accuracy_score(y_test, y_pred)
    print(f"[✓] Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, y_pred, target_names=['Not Selected', 'Selected']))
    trained_models[name] = clf

# ── Save all models + scaler in one bundle ────────────────────────────────────
bundle = {
    'scaler':              scaler,
    'random_forest':       trained_models['random_forest'],
    'logistic_regression': trained_models['logistic_regression'],
    'knn':                 trained_models['knn'],
}

with open(MODEL_PATH, 'wb') as f:
    pickle.dump(bundle, f)

print(f"\n[✓] All 3 models saved to: {MODEL_PATH}")
print("="*50)
