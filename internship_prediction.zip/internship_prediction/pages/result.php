<?php
$pageTitle = 'Prediction Result'; $pathDepth = 1;
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
if (!isset($_SESSION['last_result'])) { header('Location: predict.php'); exit; }

$r           = $_SESSION['last_result'];
$chance      = $r['selection_chance'];
$probability = $r['probability'];
$cgpa        = $r['cgpa'];
$skills      = $r['skills_list'];
$projects    = $r['projects_count'];
$recs        = $r['recommendations'];
$algorithms  = $r['algorithms'] ?? [];
$votes       = $r['votes'] ?? [];

$ringClass   = $chance === 'High' ? 'high' : ($chance === 'Medium' ? 'mid' : 'low');
$chanceColor = $chance === 'High' ? 'var(--success)' : ($chance === 'Medium' ? 'var(--warning)' : 'var(--danger)');

function algoColor($c) {
    return $c === 'High' ? 'var(--success)' : ($c === 'Medium' ? 'var(--warning)' : 'var(--danger)');
}
function algoBg($c) {
    return $c === 'High' ? 'rgba(16,185,129,0.12)' : ($c === 'Medium' ? 'rgba(245,158,11,0.12)' : 'rgba(239,68,68,0.12)');
}

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
  <div class="container" style="max-width:960px">

    <div class="text-center mb-4 fade-up">
      <p class="section-label">AI Analysis Complete — 3 Algorithms</p>
      <h2 style="font-family:'DM Serif Display',serif;font-size:2rem">Your Internship Selection Result</h2>
    </div>

    <!-- ── Row 1: Ring + Algorithm Comparison ─────────────────────────────── -->
    <div class="row g-4 mb-4">

      <!-- Ring / Ensemble -->
      <div class="col-md-5">
        <div class="card-custom text-center fade-up h-100">
          <p style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-muted);margin-bottom:0.5rem">
            Ensemble Result (Avg of 3)
          </p>
          <div class="result-ring-wrap">
            <div class="result-ring <?= $ringClass ?>">
              <?= round($probability) ?>%
              <small>probability</small>
            </div>
          </div>
          <h3 class="fw-700 mb-1" style="font-size:1.6rem;color:<?= $chanceColor ?>">
            <?= $chance ?> Chance
          </h3>
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:1.2rem">
            <?php
              if ($chance === 'High')        echo 'Excellent profile! Strong chances of getting selected.';
              elseif ($chance === 'Medium')  echo 'Good potential. A few improvements can significantly boost your chances.';
              else                           echo 'Keep building your profile. Focus on skills and projects.';
            ?>
          </p>

          <!-- Majority Vote Badges -->
          <?php if (!empty($votes)): ?>
          <div style="display:flex;gap:0.5rem;justify-content:center;flex-wrap:wrap;margin-bottom:1rem">
            <?php foreach(['High','Medium','Low'] as $v): $cnt = $votes[$v] ?? 0; if(!$cnt) continue; ?>
            <span style="font-size:0.75rem;padding:0.25rem 0.7rem;border-radius:20px;background:<?= algoBg($v) ?>;color:<?= algoColor($v) ?>;font-weight:700">
              <?= $cnt ?>/3 vote<?= $cnt>1?'s':'' ?> → <?= $v ?>
            </span>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <!-- Profile Summary -->
          <div style="background:rgba(255,255,255,0.03);border-radius:10px;padding:1rem;text-align:left">
            <p style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text-muted);margin-bottom:0.8rem">Your Profile</p>
            <div class="d-flex justify-content-between" style="font-size:0.83rem;margin-bottom:0.4rem">
              <span style="color:var(--text-muted)">CGPA</span>
              <span class="fw-700"><?= $cgpa ?> / 4.0</span>
            </div>
            <div class="d-flex justify-content-between" style="font-size:0.83rem;margin-bottom:0.4rem">
              <span style="color:var(--text-muted)">Skills</span>
              <span class="fw-700"><?= htmlspecialchars($skills ?: 'None') ?></span>
            </div>
            <div class="d-flex justify-content-between" style="font-size:0.83rem">
              <span style="color:var(--text-muted)">Projects</span>
              <span class="fw-700"><?= $projects ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- Algorithm Breakdown -->
      <div class="col-md-7">
        <div class="card-custom fade-up fade-up-d1 h-100">
          <h5 class="fw-700 mb-3">
            <i class="bi bi-cpu text-blue me-2"></i>Algorithm Comparison
          </h5>
          <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:1.2rem">
            Three different ML algorithms analyzed your profile independently. The final result is their ensemble (average + majority vote).
          </p>

          <?php foreach ($algorithms as $algo): ?>
          <div style="margin-bottom:1rem;padding:0.9rem 1rem;border-radius:12px;background:<?= algoBg($algo['chance']) ?>;border:1px solid <?= algoColor($algo['chance']) ?>30">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <div>
                <span style="font-weight:700;font-size:0.9rem"><?= $algo['name'] ?></span>
                <span style="font-size:0.72rem;margin-left:0.5rem;padding:0.15rem 0.5rem;border-radius:20px;background:rgba(255,255,255,0.08);color:var(--text-muted)"><?= $algo['short'] ?></span>
              </div>
              <span style="font-weight:700;font-size:0.85rem;color:<?= algoColor($algo['chance']) ?>">
                <?= $algo['chance'] ?> (<?= $algo['prob'] ?>%)
              </span>
            </div>
            <!-- Progress bar -->
            <div style="height:6px;border-radius:3px;background:rgba(255,255,255,0.1);overflow:hidden">
              <div style="height:100%;width:<?= $algo['prob'] ?>%;background:<?= algoColor($algo['chance']) ?>;border-radius:3px;transition:width 1s ease"></div>
            </div>
          </div>
          <?php endforeach; ?>

          <div style="margin-top:1rem;padding:0.7rem 1rem;border-radius:10px;background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.25)">
            <span style="font-size:0.8rem;color:var(--text-muted)"><i class="bi bi-info-circle me-1"></i>
              <strong style="color:var(--blue-lite)">Ensemble Method:</strong>
              Average probability of all 3 algorithms with majority vote for final label.
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Row 2: Recommendations ─────────────────────────────────────────── -->
    <div class="row g-4">
      <div class="col-12">
        <div class="card-custom fade-up">
          <h5 class="fw-700 mb-3"><i class="bi bi-lightbulb text-blue me-2"></i>Recommendations</h5>
          <div class="row g-2">
            <?php foreach ($recs as $rec): ?>
            <div class="col-md-6">
              <div class="rec-item"><i class="bi bi-check2-circle text-blue me-2"></i><?= htmlspecialchars($rec) ?></div>
            </div>
            <?php endforeach; ?>
          </div>
          <hr class="divider" style="margin:1.2rem 0">
          <div class="d-flex gap-2 flex-wrap">
            <a href="predict.php" class="btn-prime text-decoration-none"><i class="bi bi-arrow-repeat me-2"></i>Try Again</a>
            <a href="history.php" class="btn-outline-prime"><i class="bi bi-clock-history me-2"></i>History</a>
            <a href="dashboard.php" class="btn-outline-prime"><i class="bi bi-grid me-2"></i>Dashboard</a>
          </div>
        </div>
      </div>
    </div>

    <div class="alert-custom alert-info mt-4 fade-up">
      <i class="bi bi-info-circle me-2"></i>
      <strong>Note:</strong> This prediction uses an ensemble of <strong>Random Forest</strong>, <strong>Logistic Regression</strong>, and <strong>KNN</strong> algorithms. Results are for guidance only — actual selection depends on interviews, company requirements, and timing.
    </div>

  </div>
</div>
<?php unset($_SESSION['last_result']); require_once '../includes/footer.php'; ?>
